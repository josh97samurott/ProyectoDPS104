package com.example.backendcimo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendcimoApplicationTests {

	@Test
	void contextLoads() {
	}

}
